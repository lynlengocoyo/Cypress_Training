/// <reference types ="cypress"/>


describe('Launce Website Example', function(){


    it('handle alert', function(){


   cy.visit('http://only-testing-blog.blogspot.com/2013/11/new-test.html')

    })

})