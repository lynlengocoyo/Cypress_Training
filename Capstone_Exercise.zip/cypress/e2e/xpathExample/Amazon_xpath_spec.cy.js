/// <reference types = "Cypress" />

//describe('OrangeHRM Spec', ()=> {


 //hooks
 //mocha/chai/jasmine

// before( () => {

 // cy.log('Execute b')
// })

 //after ( ())


// it('verify loginfeature', () => {

  //  cy.log('---verify test----')

 //})

 //it('')

//})