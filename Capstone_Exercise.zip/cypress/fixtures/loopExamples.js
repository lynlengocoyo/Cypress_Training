

const x = require('../../fixtures/nopComLogin.json')

x.forEach( (item) => {

    console.log(item);
    console.log("------------------");
    console.log(item.email);

    
})